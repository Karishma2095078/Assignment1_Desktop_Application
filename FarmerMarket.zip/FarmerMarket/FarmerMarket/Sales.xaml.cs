﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.ComponentModel;

namespace FarmerMarket
{
    /// <summary>
    /// Interaction logic for Sales.xaml
    /// </summary>
    public partial class Sales : Window
    {
        // ******** Product class to represent a single product ********
        public class Product : INotifyPropertyChanged
        {
            public int ProductId { get; set; }
            public string ProductName { get; set; }
            public int Quantity { get; set; }
            public double Price { get; set; }

            private int userQuantity;
            public int UserQuantity
            {
                get { return userQuantity; }
                set
                {
                    if (userQuantity != value)
                    {
                        userQuantity = value;
                        OnPropertyChanged(nameof(UserQuantity));
                    }
                }
            }

            public Product(int productId, string productName, int quantity, double price)
            {
                ProductId = productId;
                ProductName = productName;
                Quantity = quantity;
                Price = price;
            }

            public override string ToString()
            {
                return ProductName;
            }

            public event PropertyChangedEventHandler PropertyChanged;
            protected virtual void OnPropertyChanged(string propertyName)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //list to store available products
        private List<Product> products;
        private List<Product> selectedProducts;

        public Sales()
        {
            InitializeComponent();

            // Load the available products from the database
            products = LoadProductsFromDatabase();

            // select multiple products
            selectedProducts = new List<Product>();

            // Bind the products to the ListBox control for display
            ListBoxProducts.ItemsSource = products;

        }

        // ******** Load the available products from the database ********
        private List<Product> LoadProductsFromDatabase()
        {
            List<Product> productList = new List<Product>();

            //Establish the database connection
            con = new NpgsqlConnection(getConnectionString());
            {
                try
                {
                    con.Open();

                    string Query = "select * from products";
                    cmd = new NpgsqlCommand(Query, con);
                    NpgsqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        int productId = Convert.ToInt32(reader["productId"]);
                        string productName = reader["productName"].ToString();
                        int amount = Convert.ToInt32(reader["amount"]);
                        double price = Convert.ToDouble(reader["price"]);

                        Product product = new Product(productId, productName, amount, price);
                        productList.Add(product);
                    }
                }catch(NpgsqlException e)
                {
                    MessageBox.Show(e.Message);
                }
            }

            return productList;
        }


        // ******** Calculate the total sales amount based on the selected products and quantities ********
        private void CalculateTotalSales()
        {
            double totalSales = 0;
            foreach (Product product in selectedProducts)
            {
                int quantity = Convert.ToInt32(product.UserQuantity); // Get the user-entered quantity
                double price = Convert.ToDouble(product.Price);

                totalSales += quantity * price;
            }
            TextTotalSales.Text = totalSales.ToString("00.00$");
        }

        //******** Event handler for the selection changed event of the ListBoxProducts ********
        private void ListBoxProducts_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            selectedProducts.Clear();
            foreach (Product product in ListBoxProducts.SelectedItems)
            {
                selectedProducts.Add(product);
            }
            CalculateTotalSales();
        }


        //******** Event handler for the "Calculate" button click ********
        private void BtnTotalSales_Click(object sender, RoutedEventArgs e)
        {
            CalculateTotalSales();

        }


        //***************** Database Connection **********************

        //Generate connection string
        private static string getConnectionString()
        {
            string host = "Host=localhost;";
            string port = "Port=5432;";
            string dbName = "Database=FarmerMarket;";
            string userName = "Username=postgres;";
            string password = "Password=postgres;";

            string connectionString = string.Format("{0}{1}{2}{3}{4}", host, port, dbName, userName, password);
            return connectionString;
        }

        //***************** Establish Connection **********************

        //Connection Adapter: helps to connect to a postgreSQL database
        public static NpgsqlConnection con;

        //Command Adapter: helps to send/execute any command in the databse
        public static NpgsqlCommand cmd;

        private static void establishConnection()
        {
            try
            {
                con = new NpgsqlConnection(getConnectionString());

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                System.Windows.Application.Current.Shutdown();
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
